# SPDX-License-Identifier: Apache-2.0
"""P67 production wrapper — multi-query TurboQuant attention for spec-decode.

Genesis-original Triton kernel for K+1 spec-verify batches against TurboQuant
compressed cache. Closes the bug class identified in noonghunna's #40880
(MTP/Eagle drafter spec-verify cudagraph capture corruption).

================================================================
v8 OPTIMIZATIONS (2026-04-26) — based on multi-agent research:

1. **BLOCK_M fusion**: drop separate BLOCK_H dim, use BLOCK_M = K_PLUS_1 × HEADS_PER_KV.
   For Qwen3.6 (K+1=4, Hq=8 per worker, Hk=1 → HEADS_PER_KV=8): BLOCK_M=32.
   v4 used BLOCK_H=16 with 50% padding waste. Mirrors vLLM
   `kernel_unified_attention` BLOCK_M heuristic.

2. **K loaded directly transposed** as [HEAD_SIZE, TILE_SIZE]: drop the per-iter
   `tl.trans()` op. Mirror upstream stride-trick.

3. **`out_dtype=tl.float32`** explicit on every `tl.dot` — critical for MMA
   path picker on Ampere SM 8.6. Without it, perf regresses ~25%.

4. **Sanitization preserved** — Inf/NaN→0 in K and V dequant remains our
   unique mitigation against e4b15 saturation.

================================================================
WHY THIS KERNEL EXISTS

P65 workaround (downgrading TurboQuant `_cudagraph_support` to
UNIFORM_SINGLE_TOKEN_DECODE) restores correctness but forces ALL spec-decode
batches to PIECEWISE eager mode → ~30-40% throughput hit.

P67 is the proper fix: a Triton kernel that handles K+1 query tokens against
TurboQuant compressed KV cache directly, supporting FULL cudagraph capture.

================================================================
Cross-arch support:
  - Ampere SM 8.0/8.6 (A100, A5000, A6000): TESTED on A5000, FP8 e4b15
  - Ada SM 8.9 (RTX 4090): same e4b15 path, untested
  - Hopper SM 9.0+ (H100, H200): e4nv path, untested

Author: Sandermage (Sander) Barzov Aleksandr, Ukraine, Odessa.
"""
from __future__ import annotations

import logging
import math
import os
from typing import Any

log = logging.getLogger("genesis.kernels.p67")

_ENV_ENABLE = "GENESIS_ENABLE_P67_TQ_MULTI_QUERY_KERNEL"


def _env_enabled() -> bool:
    return os.environ.get(_ENV_ENABLE, "").strip().lower() in (
        "1", "true", "yes", "on"
    )


_CACHED_KERNEL = None


def _build_kernel():
    """Define the v8 Triton kernel. Returns None on import failure."""
    try:
        from vllm.triton_utils import tl, triton
    except Exception:
        try:
            import triton
            import triton.language as tl
        except Exception:
            return None

    @triton.jit
    def _p67_v8_compressed_cache(
        Q_ptr,
        KV_cache_ptr,
        Block_table_ptr,
        Seq_lens_ptr,
        K_chunk_ptr,
        V_chunk_ptr,
        O_ptr,
        stride_qb, stride_qt, stride_qh, stride_qd,
        stride_cache_block, stride_cache_pos, stride_cache_head,
        stride_bt_b,
        stride_kkb, stride_kkt, stride_kkh, stride_kkd,
        stride_vkb, stride_vkt, stride_vkh, stride_vkd,
        stride_ob, stride_ot, stride_oh, stride_od,
        SCALE: tl.constexpr,
        K_PLUS_1: tl.constexpr,
        BLOCK_D: tl.constexpr,
        HEAD_DIM: tl.constexpr,
        BLOCK_SIZE: tl.constexpr,
        BLOCK_KV: tl.constexpr,
        HEADS_PER_KV: tl.constexpr,
        Hq_TOTAL: tl.constexpr,
        KPS: tl.constexpr,
        VAL_DATA_BYTES: tl.constexpr,
        FP8_E4B15: tl.constexpr = 0,
    ):
        bid = tl.program_id(0)
        kv_head = tl.program_id(1)

        BLOCK_M: tl.constexpr = K_PLUS_1 * HEADS_PER_KV

        offs_m = tl.arange(0, BLOCK_M)
        q_t = offs_m // HEADS_PER_KV
        head_in_group = offs_m % HEADS_PER_KV
        abs_head = kv_head * HEADS_PER_KV + head_in_group
        head_mask = abs_head < Hq_TOTAL

        # vLLM convention: seq_lens[i] = TOTAL length INCLUDING K_PLUS_1 chunk.
        # Phase 1 must read ONLY prior positions [0, total - K_PLUS_1).
        total_seq_len = tl.load(Seq_lens_ptr + bid)
        prior_seq_len = total_seq_len - K_PLUS_1

        offs_d = tl.arange(0, BLOCK_D)
        d_mask = offs_d < HEAD_DIM
        offs_kv = tl.arange(0, BLOCK_KV)
        vb_idx = offs_d // 2
        vb_shift = (offs_d % 2) * 4

        # Load Q [BLOCK_M, BLOCK_D]
        q_addrs = (
            bid * stride_qb
            + q_t[:, None] * stride_qt
            + abs_head[:, None] * stride_qh
            + offs_d[None, :] * stride_qd
        )
        Q = tl.load(
            Q_ptr + q_addrs,
            mask=head_mask[:, None] & d_mask[None, :],
            other=0.0,
        )

        M_state = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
        L_state = tl.zeros([BLOCK_M], dtype=tl.float32)
        acc = tl.zeros([BLOCK_M, BLOCK_D], dtype=tl.float32)

        bt_base = bid * stride_bt_b

        # ════════════════════════════════════════════════════════════════
        # PHASE 1 — prior cached KV (compressed read, no causal mask)
        # ════════════════════════════════════════════════════════════════
        for start_n in range(0, prior_seq_len, BLOCK_KV):
            seq_offset = start_n + offs_kv
            tile_mask = seq_offset < prior_seq_len

            page_idx = seq_offset // BLOCK_SIZE
            page_off = seq_offset % BLOCK_SIZE
            physical_block = tl.load(
                Block_table_ptr + bt_base + page_idx,
                mask=tile_mask, other=0,
            ).to(tl.int64)
            slot_bases = (
                physical_block * stride_cache_block
                + page_off.to(tl.int64) * stride_cache_pos
                + tl.cast(kv_head, tl.int64) * stride_cache_head
            )

            # K loaded transposed: [HEAD_SIZE, TILE_SIZE]
            k_addrs = slot_bases[None, :] + offs_d[:, None]
            k_raw = tl.load(
                KV_cache_ptr + k_addrs,
                mask=d_mask[:, None] & tile_mask[None, :],
                other=0,
            )
            if FP8_E4B15:
                k_float = k_raw.to(tl.float8e4b15, bitcast=True).to(tl.float32)
            else:
                k_float = k_raw.to(tl.float8e4nv, bitcast=True).to(tl.float32)
            # Sanitize Inf/NaN — e4b15 saturation guard. Unique upstream gap.
            k_safe = tl.where(
                (k_float == k_float) & (k_float < 1e30) & (k_float > -1e30),
                k_float, 0.0,
            )

            # S = scale * Q @ K, fp32 accumulator (critical for MMA path picker)
            S = SCALE * tl.dot(Q, k_safe.to(Q.dtype), out_dtype=tl.float32)
            S = tl.where(
                head_mask[:, None] & tile_mask[None, :],
                S, float("-inf"),
            )

            M_new = tl.maximum(tl.max(S, axis=1), M_state)
            alpha = tl.exp(M_state - M_new)
            P = tl.exp(S - M_new[:, None])
            L_state = L_state * alpha + tl.sum(P, axis=1)
            acc = acc * alpha[:, None]

            # V dequant — 4-bit + scale + zero
            val_bases = slot_bases + KPS
            val_addrs = val_bases[:, None] + vb_idx[None, :]
            val_raw = tl.load(
                KV_cache_ptr + val_addrs,
                mask=tile_mask[:, None] & d_mask[None, :],
                other=0,
            ).to(tl.int32)
            v_idx = ((val_raw >> vb_shift[None, :]) & 0xF).to(tl.float32)

            sc_bases = val_bases + VAL_DATA_BYTES
            sc_lo = tl.load(KV_cache_ptr + sc_bases, mask=tile_mask, other=0).to(tl.uint16)
            sc_hi = tl.load(KV_cache_ptr + sc_bases + 1, mask=tile_mask, other=0).to(tl.uint16)
            v_scales = (sc_lo | (sc_hi << 8)).to(tl.float16, bitcast=True).to(tl.float32)
            zr_lo = tl.load(KV_cache_ptr + sc_bases + 2, mask=tile_mask, other=0).to(tl.uint16)
            zr_hi = tl.load(KV_cache_ptr + sc_bases + 3, mask=tile_mask, other=0).to(tl.uint16)
            v_zeros = (zr_lo | (zr_hi << 8)).to(tl.float16, bitcast=True).to(tl.float32)
            V_dequant = v_idx * v_scales[:, None] + v_zeros[:, None]
            V_safe = tl.where(
                (V_dequant == V_dequant) & (V_dequant < 1e30) & (V_dequant > -1e30),
                V_dequant, 0.0,
            )

            acc += tl.dot(P.to(Q.dtype), V_safe.to(Q.dtype), out_dtype=tl.float32)
            M_state = M_new

        # ════════════════════════════════════════════════════════════════
        # PHASE 2 — current chunk K/V (uncompressed FP16, with causal mask)
        # ════════════════════════════════════════════════════════════════
        chunk_offs = tl.arange(0, BLOCK_KV)
        chunk_mask = chunk_offs < K_PLUS_1

        kk_base = bid * stride_kkb + tl.cast(kv_head, tl.int64) * stride_kkh
        vk_base = bid * stride_vkb + tl.cast(kv_head, tl.int64) * stride_vkh

        # K_chunk loaded as [BLOCK_D, BLOCK_KV] (transposed)
        k_chunk_addrs = (
            kk_base
            + offs_d[:, None] * stride_kkd
            + chunk_offs[None, :] * stride_kkt
        )
        K_chunk = tl.load(
            K_chunk_ptr + k_chunk_addrs,
            mask=d_mask[:, None] & chunk_mask[None, :],
            other=0.0,
        )

        v_chunk_addrs = (
            vk_base
            + chunk_offs[:, None] * stride_vkt
            + offs_d[None, :] * stride_vkd
        )
        V_chunk = tl.load(
            V_chunk_ptr + v_chunk_addrs,
            mask=chunk_mask[:, None] & d_mask[None, :],
            other=0.0,
        )

        S_chunk = SCALE * tl.dot(Q, K_chunk.to(Q.dtype), out_dtype=tl.float32)

        causal_mask = q_t[:, None] >= chunk_offs[None, :]
        valid = head_mask[:, None] & chunk_mask[None, :] & causal_mask
        S_chunk = tl.where(valid, S_chunk, float("-inf"))

        M_new = tl.maximum(tl.max(S_chunk, axis=1), M_state)
        alpha = tl.exp(M_state - M_new)
        P_chunk = tl.exp(S_chunk - M_new[:, None])
        L_state = L_state * alpha + tl.sum(P_chunk, axis=1)
        acc = acc * alpha[:, None]
        acc += tl.dot(P_chunk.to(Q.dtype), V_chunk.to(Q.dtype), out_dtype=tl.float32)

        M_state = M_new

        safe_L = tl.where(L_state > 0.0, L_state, 1.0)
        out = acc / safe_L[:, None]

        o_addrs = (
            bid * stride_ob
            + q_t[:, None] * stride_ot
            + abs_head[:, None] * stride_oh
            + offs_d[None, :] * stride_od
        )
        tl.store(
            O_ptr + o_addrs, out,
            mask=head_mask[:, None] & d_mask[None, :],
        )

    return _p67_v8_compressed_cache


def _get_kernel():
    global _CACHED_KERNEL
    if _CACHED_KERNEL is None:
        _CACHED_KERNEL = _build_kernel()
    return _CACHED_KERNEL


def _autoconfig(sm_major: int, sm_minor: int, head_dim: int) -> dict:
    """Pick BLOCK_KV/num_warps/num_stages per SM."""
    if sm_major >= 9:
        return dict(BLOCK_KV=32, num_warps=8, num_stages=3)
    if sm_major == 8 and sm_minor >= 9:
        return dict(BLOCK_KV=32, num_warps=4, num_stages=2)
    if sm_major == 8 and sm_minor == 0:
        return dict(BLOCK_KV=32, num_warps=8, num_stages=3)
    if sm_major == 8:
        return dict(BLOCK_KV=16, num_warps=4, num_stages=2)
    return dict(BLOCK_KV=16, num_warps=4, num_stages=2)


def _detect_fp8_mode() -> int:
    try:
        import torch
        cap = torch.cuda.get_device_capability()
        return 1 if cap < (8, 9) else 0
    except Exception:
        return 1


def is_active() -> bool:
    if not _env_enabled():
        return False
    if _get_kernel() is None:
        return False
    return True


def call_p67_attention(
    q,
    kv_cache,
    block_table,
    seq_lens,
    k_chunk,
    v_chunk,
    scale: float,
    block_size: int,
    kps: int,
    val_data_bytes: int,
    output=None,
):
    """Production launcher for P67 v8 multi-query attention."""
    import torch
    import triton

    kernel = _get_kernel()
    if kernel is None:
        raise ImportError("P67 Triton kernel not available")

    B, K_PLUS_1, Hq, D = q.shape
    Hk = k_chunk.shape[2]
    assert k_chunk.shape == (B, K_PLUS_1, Hk, D)
    assert v_chunk.shape == (B, K_PLUS_1, Hk, D)
    assert Hq % Hk == 0
    heads_per_kv = Hq // Hk

    cap = torch.cuda.get_device_capability()
    cfg = _autoconfig(cap[0], cap[1], D)

    BLOCK_D = triton.next_power_of_2(D)

    if output is None:
        output = torch.empty_like(q, dtype=torch.float32)

    fp8_e4b15 = _detect_fp8_mode()

    grid = (B, Hk, 1)
    kernel[grid](
        q, kv_cache, block_table, seq_lens,
        k_chunk, v_chunk, output,
        q.stride(0), q.stride(1), q.stride(2), q.stride(3),
        kv_cache.stride(0), kv_cache.stride(1), kv_cache.stride(2),
        block_table.stride(0),
        k_chunk.stride(0), k_chunk.stride(1), k_chunk.stride(2), k_chunk.stride(3),
        v_chunk.stride(0), v_chunk.stride(1), v_chunk.stride(2), v_chunk.stride(3),
        output.stride(0), output.stride(1), output.stride(2), output.stride(3),
        SCALE=scale,
        K_PLUS_1=K_PLUS_1,
        BLOCK_D=BLOCK_D,
        HEAD_DIM=D,
        BLOCK_SIZE=block_size,
        BLOCK_KV=cfg["BLOCK_KV"],
        HEADS_PER_KV=heads_per_kv,
        Hq_TOTAL=Hq,
        KPS=kps,
        VAL_DATA_BYTES=val_data_bytes,
        FP8_E4B15=fp8_e4b15,
        num_warps=cfg["num_warps"],
        num_stages=cfg["num_stages"],
    )
    return output.to(q.dtype)


def diagnostic_info() -> dict[str, Any]:
    info = {"env_enabled": _env_enabled(), "version": "v8_block_m_fp32acc"}
    try:
        import torch
        if torch.cuda.is_available():
            cap = torch.cuda.get_device_capability()
            info["sm"] = f"{cap[0]}.{cap[1]}"
            info["fp8_mode"] = "e4b15" if cap < (8, 9) else "e4nv"
            info["autoconfig"] = _autoconfig(cap[0], cap[1], 128)
        else:
            info["cuda"] = False
    except Exception as e:
        info["error"] = str(e)
    info["kernel_built"] = _get_kernel() is not None
    return info
