# SPDX-License-Identifier: Apache-2.0
"""Wiring for Patch 67 — TurboQuant multi-query kernel for spec-decode K+1 batches.

Genesis-original. The PROPER fix for noonghunna's #40880 bug class
(MTP × TurboQuant × FULL cudagraph degenerate output). P65 was a
workaround (downgrades cudagraph_mode to PIECEWISE → ~30% throughput hit);
P67 replaces it by handling K+1 batches in a Triton kernel that supports
FULL cudagraph capture.

================================================================
WHAT THIS PATCH DOES

Inserts a hook at the top of `TurboQuantAttentionImpl._prefill_attention`.
For K+1 spec-verify continuation-prefill batches (multi-query AND has
prior cached KV) AND when env GENESIS_ENABLE_P67_TQ_MULTI_QUERY_KERNEL=1,
routes the batch through our P67 multi-query Triton kernel instead of
the buggy bypass / slow per-request continuation loop.

For all other shapes (true first-chunk prefill, pure decode, non-spec-decode
continuation) the existing upstream logic runs unchanged.

================================================================
SAFETY / FALLBACK

- env-gated (default OFF) — operator must explicitly enable
- on any P67 exception, falls through to existing eager continuation branch
- if Triton kernel fails to build (CPU-only host etc.), kernel.is_active()
  returns False → hook is no-op
- preserves bit-for-bit behavior when env flag is off

After P67 is empirically validated:
  1. Restore P65 to declare UNIFORM_BATCH (no longer need cudagraph downgrade)
  2. Spec-decode batches regain FULL cudagraph speedup
  3. Net effect: P64+P65v2+P66+P67 = correct + fast

Author: Sandermage (Sander) Barzov Aleksandr, Ukraine, Odessa.
"""
from __future__ import annotations

import logging
import os

from vllm._genesis.guards import resolve_vllm_file, vllm_install_root
from vllm._genesis.wiring.text_patch import (
    TextPatcher,
    TextPatchResult,
    TextPatch,
)

log = logging.getLogger("genesis.wiring.p67_tq_multi_query_kernel")

GENESIS_P67_MARKER = "Genesis P67 TQ multi-query kernel for spec-decode K+1 v7.22_no_nan_sync"


# ─── Sub-patch: insert P67 hook at top of _prefill_attention ────────────────
# Anchor on the function signature + initial fast-path check. Insert P67
# dispatch BEFORE the fast path so we can intercept K+1 continuation cases
# that the fast path's `max_query_len == max_seq_len` guard skips.

P67_OLD = (
    "    ) -> torch.Tensor:\n"
    "        N, Hq, D = query.shape\n"
    "\n"
    "        # Fast path: use flash_attn for first-chunk prefills (all K/V in batch).\n"
    "        # max_query_len == max_seq_len means no request has prior cached KV.\n"
    "        # Both are Python ints — no GPU sync.\n"
    "        if _HAS_FLASH_ATTN and attn_metadata.max_query_len == attn_metadata.max_seq_len:\n"
)

P67_NEW = (
    "    ) -> torch.Tensor:\n"
    "        N, Hq, D = query.shape\n"
    "\n"
    "        # [Genesis P67 vllm-genesis] Multi-query continuation prefill hook.\n"
    "        # If batch is K+1 spec-verify continuation (multi-query AND has prior\n"
    "        # cached KV) AND env GENESIS_ENABLE_P67_TQ_MULTI_QUERY_KERNEL=1,\n"
    "        # route to our Triton kernel that handles compressed cache directly\n"
    "        # under FULL cudagraph (proper fix vs P65 workaround).\n"
    "        try:\n"
    "            from vllm._genesis.kernels.p67_multi_query_kernel import (\n"
    "                is_active as _genesis_p67_is_active,\n"
    "                call_p67_attention as _genesis_p67_call,\n"
    "            )\n"
    "            import logging as _genesis_p67_logging\n"
    "            _genesis_p67_log = _genesis_p67_logging.getLogger('genesis.kernels.p67')\n"
    "            if not hasattr(self, '_genesis_p67_entry_count'):\n"
    "                self._genesis_p67_entry_count = 0\n"
    "            self._genesis_p67_entry_count += 1\n"
    "            if self._genesis_p67_entry_count <= 3:\n"
    "                _genesis_p67_log.warning(\n"
    "                    'P67 hook ENTRY #%d: N=%d Hq=%d D=%d Hk=%d max_q=%s max_s=%s active=%s',\n"
    "                    self._genesis_p67_entry_count, N, Hq, D, key.shape[1],\n"
    "                    attn_metadata.max_query_len, attn_metadata.max_seq_len,\n"
    "                    _genesis_p67_is_active(),\n"
    "                )\n"
    "            # Shape guard: P67 v1 supports D in {128, 256}, Hq>=8, GQA>=2.\n"
    "            # NaN guard below catches any unexpected output and falls through\n"
    "            # to upstream rather than poisoning the engine.\n"
    "            _genesis_p67_Hk = key.shape[1]\n"
    "            _genesis_p67_shape_ok = (\n"
    "                Hq >= 8 and D in (128, 256) and (Hq // _genesis_p67_Hk) >= 2\n"
    "            )\n"
    "            _genesis_p67_dispatch = (\n"
    "                _genesis_p67_is_active()\n"
    "                and _genesis_p67_shape_ok\n"
    "                and attn_metadata.max_query_len > 1\n"
    "                and attn_metadata.max_seq_len > attn_metadata.max_query_len\n"
    "                and N > 0\n"
    "                and (N % attn_metadata.max_query_len) == 0\n"
    "            )\n"
    "            if not hasattr(self, '_genesis_p67_call_count'):\n"
    "                self._genesis_p67_call_count = 0\n"
    "                self._genesis_p67_dispatch_count = 0\n"
    "            self._genesis_p67_call_count += 1\n"
    "            if _genesis_p67_dispatch:\n"
    "                self._genesis_p67_dispatch_count += 1\n"
    "                _genesis_p67_K_PLUS_1 = attn_metadata.max_query_len\n"
    "                _genesis_p67_B = N // _genesis_p67_K_PLUS_1\n"
    "                _genesis_p67_qsl = attn_metadata.query_start_loc\n"
    "                if (\n"
    "                    _genesis_p67_qsl is not None\n"
    "                    and _genesis_p67_qsl.shape[0] == _genesis_p67_B + 1\n"
    "                ):\n"
    "                    Hk_genesis = key.shape[1]\n"
    "                    _genesis_p67_q = query.contiguous().view(\n"
    "                        _genesis_p67_B, _genesis_p67_K_PLUS_1, Hq, D\n"
    "                    )\n"
    "                    _genesis_p67_k_chunk = key.contiguous().view(\n"
    "                        _genesis_p67_B, _genesis_p67_K_PLUS_1, Hk_genesis, D\n"
    "                    )\n"
    "                    _genesis_p67_v_chunk = value.contiguous().view(\n"
    "                        _genesis_p67_B, _genesis_p67_K_PLUS_1, Hk_genesis, D\n"
    "                    )\n"
    "                    _genesis_p67_cfg = self.tq_config\n"
    "                    _genesis_p67_block_size = kv_cache.shape[1]\n"
    "                    _genesis_p67_kps = _genesis_p67_cfg.key_packed_size\n"
    "                    _genesis_p67_vdb = _genesis_p67_cfg.value_data_bytes if hasattr(_genesis_p67_cfg, 'value_data_bytes') else (D // 2)\n"
    "                    if self._genesis_p67_dispatch_count <= 3:\n"
    "                        _genesis_p67_log.warning(\n"
    "                            'P67 dispatch #%d: B=%d K_PLUS_1=%d Hq=%d Hk=%d D=%d block_size=%d kps=%d vdb=%d max_seq=%d',\n"
    "                            self._genesis_p67_dispatch_count, _genesis_p67_B,\n"
    "                            _genesis_p67_K_PLUS_1, Hq, Hk_genesis, D,\n"
    "                            _genesis_p67_block_size, _genesis_p67_kps, _genesis_p67_vdb,\n"
    "                            attn_metadata.max_seq_len,\n"
    "                        )\n"
    "                    _genesis_p67_out = _genesis_p67_call(\n"
    "                        q=_genesis_p67_q,\n"
    "                        kv_cache=kv_cache,\n"
    "                        block_table=attn_metadata.block_table,\n"
    "                        seq_lens=attn_metadata.seq_lens,\n"
    "                        k_chunk=_genesis_p67_k_chunk,\n"
    "                        v_chunk=_genesis_p67_v_chunk,\n"
    "                        scale=self.scale,\n"
    "                        block_size=_genesis_p67_block_size,\n"
    "                        kps=_genesis_p67_kps,\n"
    "                        val_data_bytes=_genesis_p67_vdb,\n"
    "                    )\n"
    "                    # Kernel is sanitized internally (Inf/NaN→0 in K/V dequant).\n"
    "                    # Trust output; no per-call GPU sync. Log first 3 dispatches.\n"
    "                    if self._genesis_p67_dispatch_count <= 3:\n"
    "                        _genesis_p67_log.warning(\n"
    "                            'P67 dispatch #%d OK: out shape=%s',\n"
    "                            self._genesis_p67_dispatch_count, tuple(_genesis_p67_out.shape),\n"
    "                        )\n"
    "                    return _genesis_p67_out.view(N, Hq, D)\n"
    "        except Exception as _genesis_p67_err:\n"
    "            import logging as _genesis_p67_logging\n"
    "            _genesis_p67_logging.getLogger('genesis.kernels.p67').warning(\n"
    "                'P67 dispatch failed (%s), falling through to upstream',\n"
    "                _genesis_p67_err, exc_info=True,\n"
    "            )\n"
    "\n"
    "        # Fast path: use flash_attn for first-chunk prefills (all K/V in batch).\n"
    "        # max_query_len == max_seq_len means no request has prior cached KV.\n"
    "        # Both are Python ints — no GPU sync.\n"
    "        if _HAS_FLASH_ATTN and attn_metadata.max_query_len == attn_metadata.max_seq_len:\n"
)


def _make_patcher() -> TextPatcher | None:
    target = resolve_vllm_file("v1/attention/backends/turboquant_attn.py")
    if target is None:
        return None
    return TextPatcher(
        patch_name="P67 turboquant_attn.py — multi-query kernel hook",
        target_file=str(target),
        marker=GENESIS_P67_MARKER,
        sub_patches=[
            TextPatch(
                name="p67_kernel_hook",
                anchor=P67_OLD,
                replacement=P67_NEW,
                required=True,
            ),
        ],
        upstream_drift_markers=[
            "[Genesis P67",
            "_genesis_p67_call",
            "TQ multi-query kernel",
        ],
    )


def apply() -> tuple[str, str]:
    """Apply P67 hook injection."""
    from vllm._genesis.dispatcher import should_apply, log_decision
    decision, reason = should_apply("P67")
    log_decision("P67", decision, reason)
    if not decision:
        return "skipped", reason

    if vllm_install_root() is None:
        return "skipped", "vllm install root not discoverable"

    patcher = _make_patcher()
    if patcher is None:
        return "skipped", "turboquant_attn.py not found"

    if not os.path.isfile(patcher.target_file):
        return "skipped", f"target disappeared: {patcher.target_file}"
    with open(patcher.target_file) as f:
        content = f.read()
    if patcher.marker in content:
        pass
    else:
        for m in patcher.upstream_drift_markers:
            if m in content:
                return (
                    "skipped",
                    f"upstream drift marker {m!r} in {patcher.target_file} — "
                    "P67 likely already injected.",
                )
        if patcher.sub_patches[0].anchor not in content:
            return (
                "skipped",
                "required anchor (_prefill_attention top + fast-path check) not "
                "found — upstream drift; P67 cannot apply.",
            )

    result, failure = patcher.apply()
    if result == TextPatchResult.FAILED:
        return "failed", (
            f"{patcher.patch_name}: {failure.reason if failure else 'unknown'} "
            f"({failure.detail if failure else ''})"
        )

    # Diagnostic info for log
    diag = ""
    try:
        from vllm._genesis.kernels.p67_multi_query_kernel import diagnostic_info
        diag = f" Diag: {diagnostic_info()}"
    except Exception:
        pass

    return "applied", (
        "P67 hook injected at top of _prefill_attention. Multi-query continuation "
        "prefill batches (spec-verify K+1 with prior cached KV) will route to "
        "Genesis Triton kernel when GENESIS_ENABLE_P67_TQ_MULTI_QUERY_KERNEL=1." + diag
    )
