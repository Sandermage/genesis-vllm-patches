# SPDX-License-Identifier: Apache-2.0
"""P67 production wrapper — multi-query TurboQuant attention for spec-decode.

Genesis-original Triton kernel for K+1 spec-verify batches against TurboQuant
compressed cache. Closes the bug class identified in noonghunna's #40880
(MTP/Eagle drafter spec-verify cudagraph capture corruption).

================================================================
WHY THIS KERNEL EXISTS

P65 workaround (downgrading TurboQuant `_cudagraph_support` to
UNIFORM_SINGLE_TOKEN_DECODE) restores correctness but forces ALL spec-decode
batches to PIECEWISE eager mode → ~30-40% throughput hit because attention
runs as N kernel launches per piece instead of one captured graph.

P67 is the proper fix: a Triton kernel that handles K+1 query tokens against
TurboQuant compressed KV cache directly, supporting FULL cudagraph capture.
Once P67 is enabled and validated, P65 can be restored to UNIFORM_BATCH and
spec-decode regains FULL cudagraph speedup.

================================================================
KERNEL DESIGN

Reads cached KV from TurboQuant k8v4 layout directly:
  Per-slot byte layout:
    [0..KPS)              FP8 K (e4b15 on Ampere/Ada, e4nv on Hopper+)
    [KPS..KPS+VDB)        4-bit V indices (2 nibbles per byte)
    [KPS+VDB..KPS+VDB+2)  V scale (FP16 little-endian)
    [KPS+VDB+2..KPS+VDB+4) V zero  (FP16 little-endian)

Cache memory: [num_blocks, block_size, Hk, padded_slot] uint8

Algorithm:
  Phase 1 — prior cached KV: paged loop over BLOCK_KV-sized tiles, online
            softmax accumulator per (q_token, head), no causal mask
            (all prior positions are reachable by all q tokens).
  Phase 2 — current chunk K/V: K_PLUS_1 positions in FP16, padded to BLOCK_KV
            (Triton tl.dot dim ≥ 16 requirement), causal mask
            `qt_idx[t] >= chunk_idx[k]` applied within tile.

Grid: (batch, num_head_groups, 1)
  - Each CTA handles BLOCK_H query heads sharing one KV head
  - For Qwen3.6-35B-A3B (Hq=64, Hk=4, GQA=16): num_head_groups = 4

Memory: per-CTA shared mem footprint
  - Q tile: K_PLUS_1 × BLOCK_H × BLOCK_D fp16 = 4×16×128 × 2 = 16 KB
  - K tile: BLOCK_KV × BLOCK_D fp16 = 16×128 × 2 = 4 KB
  - V tile: same 4 KB
  - Softmax state + acc: K_PLUS_1 × BLOCK_H × BLOCK_D fp32 = 32 KB
  - Total: ~60 KB per CTA (fits in 100 KB Ampere SM 8.6 shared mem cap)

Cross-arch support:
  - Ampere SM 8.0/8.6 (A100, A5000, A6000): TESTED on A5000, FP8 e4b15
  - Ada SM 8.9 (RTX 4090): same e4b15 path, untested
  - Hopper SM 9.0+ (H100, H200): e4nv path, untested
  - Blackwell SM 10.0/12.0 (B200, GB200): e4nv path, untested
  - Volta SM 7.0 / Turing SM 7.5: tl.dot fp16 may fall back to non-tensor-core

Author: Sandermage (Sander) Barzov Aleksandr, Ukraine, Odessa.
"""
from __future__ import annotations

import logging
import math
import os
from typing import Any

log = logging.getLogger("genesis.kernels.p67")

_ENV_ENABLE = "GENESIS_ENABLE_P67_TQ_MULTI_QUERY_KERNEL"


def _env_enabled() -> bool:
    return os.environ.get(_ENV_ENABLE, "").strip().lower() in (
        "1", "true", "yes", "on"
    )


# Compiled kernel cached lazily — built on first use to avoid import-time
# Triton dependency on CPU-only test hosts.
_CACHED_KERNEL = None


def _build_kernel():
    """Define the Triton kernel. Returns None on import failure."""
    try:
        from vllm.triton_utils import tl, triton
    except Exception:
        try:
            import triton
            import triton.language as tl
        except Exception:
            return None

    @triton.jit
    def _p67_v4_compressed_cache(
        Q_ptr,
        KV_cache_ptr,
        Block_table_ptr,
        Seq_lens_ptr,
        K_chunk_ptr,
        V_chunk_ptr,
        O_ptr,
        stride_qb, stride_qt, stride_qh, stride_qd,
        stride_cache_block, stride_cache_pos, stride_cache_head,
        stride_bt_b,
        stride_kkb, stride_kkt, stride_kkh, stride_kkd,
        stride_vkb, stride_vkt, stride_vkh, stride_vkd,
        stride_ob, stride_ot, stride_oh, stride_od,
        SCALE: tl.constexpr,
        K_PLUS_1: tl.constexpr,
        BLOCK_D: tl.constexpr,
        HEAD_DIM: tl.constexpr,
        BLOCK_SIZE: tl.constexpr,
        BLOCK_KV: tl.constexpr,
        BLOCK_H: tl.constexpr,
        KV_GROUP_SIZE: tl.constexpr,
        Hq_TOTAL: tl.constexpr,
        KPS: tl.constexpr,
        VAL_DATA_BYTES: tl.constexpr,
        FP8_E4B15: tl.constexpr = 0,
        SKIP_PHASE_1: tl.constexpr = 0,  # DEBUG: skip cache-read phase
    ):
        bid = tl.program_id(0)
        head_group_id = tl.program_id(1)

        heads_per_kv: tl.constexpr = tl.cdiv(KV_GROUP_SIZE, BLOCK_H)
        kv_head = head_group_id // heads_per_kv
        group_idx_in_kv = head_group_id % heads_per_kv
        cur_head = (
            kv_head * KV_GROUP_SIZE
            + group_idx_in_kv * BLOCK_H
            + tl.arange(0, BLOCK_H)
        )
        mask_h = (
            (cur_head < (kv_head + 1) * KV_GROUP_SIZE)
            & (cur_head < Hq_TOTAL)
        )

        # CRITICAL: attn_metadata.seq_lens[i] is TOTAL length INCLUDING the
        # K_PLUS_1 new tokens which `do_kv_cache_update` already wrote to cache
        # BEFORE _prefill_attention is called. Phase 1 must read ONLY prior
        # tokens (positions [0, total - K_PLUS_1)). Phase 2 then handles the
        # K_PLUS_1 chunk via uncompressed K/V buffers with causal mask.
        # Without this subtraction Phase 1 re-reads the chunk positions
        # WITHOUT causal mask → double-counting + causality violation → NaN.
        total_seq_len = tl.load(Seq_lens_ptr + bid)
        prior_seq_len = total_seq_len - K_PLUS_1

        d_offs = tl.arange(0, BLOCK_D)
        d_mask = d_offs < HEAD_DIM
        qt_range = tl.arange(0, K_PLUS_1)
        kv_range = tl.arange(0, BLOCK_KV)
        vb_idx = d_offs // 2
        vb_shift = (d_offs % 2) * 4

        # Load Q [K_PLUS_1, BLOCK_H, BLOCK_D]
        q_base = bid * stride_qb
        q_addrs = (
            q_base
            + qt_range[:, None, None] * stride_qt
            + cur_head[None, :, None] * stride_qh
            + d_offs[None, None, :] * stride_qd
        )
        q = tl.load(
            Q_ptr + q_addrs,
            mask=mask_h[None, :, None] & d_mask[None, None, :],
            other=0.0,
        ).to(tl.float32)
        q_2d = tl.reshape(q, [K_PLUS_1 * BLOCK_H, BLOCK_D])

        m_prev = tl.zeros([K_PLUS_1, BLOCK_H], dtype=tl.float32) - float("inf")
        l_prev = tl.zeros([K_PLUS_1, BLOCK_H], dtype=tl.float32)
        acc = tl.zeros([K_PLUS_1, BLOCK_H, BLOCK_D], dtype=tl.float32)

        bt_base = bid * stride_bt_b

        # Phase 1: prior cached KV (compressed read, no causal — all prior
        # positions are reachable by ALL q tokens). Loop only over PRIOR
        # range, not the K_PLUS_1 chunk that's now in cache.
        # DEBUG: if SKIP_PHASE_1=1, treat as if no prior context (test Phase 2 only)
        _phase1_end = 0 if SKIP_PHASE_1 else prior_seq_len
        for start_n in range(0, _phase1_end, BLOCK_KV):
            kv_offs = start_n + kv_range
            kv_mask = kv_offs < prior_seq_len

            page_idx = kv_offs // BLOCK_SIZE
            page_off = kv_offs % BLOCK_SIZE
            block_nums = tl.load(
                Block_table_ptr + bt_base + page_idx,
                mask=kv_mask, other=0,
            ).to(tl.int64)
            slot_bases = (
                block_nums * stride_cache_block
                + page_off.to(tl.int64) * stride_cache_pos
                + tl.cast(kv_head, tl.int64) * stride_cache_head
            )

            # K dequant — FP8
            k_addrs = slot_bases[:, None] + d_offs[None, :]
            k_raw = tl.load(
                KV_cache_ptr + k_addrs,
                mask=kv_mask[:, None] & d_mask[None, :],
                other=0,
            )
            if FP8_E4B15:
                k_float = k_raw.to(tl.float8e4b15, bitcast=True).to(tl.float32)
            else:
                k_float = k_raw.to(tl.float8e4nv, bitcast=True).to(tl.float32)
            # Sanitize: FP8 e4b15 has 4-bit exp field = 15 → inf/nan. Production
            # cache occasionally contains such bytes (uninit slots, saturated
            # quant). Treat as 0 to avoid poisoning softmax accumulator.
            # NaN != NaN trick + Inf check via finite range comparison.
            k_float = tl.where((k_float == k_float) & (k_float < 1e30) & (k_float > -1e30),
                               k_float, 0.0)

            scores_2d = tl.dot(
                q_2d.to(tl.float16),
                tl.trans(k_float.to(tl.float16)),
                out_dtype=tl.float32,
            ) * SCALE
            scores = tl.reshape(scores_2d, [K_PLUS_1, BLOCK_H, BLOCK_KV])
            scores = tl.where(
                mask_h[None, :, None] & kv_mask[None, None, :],
                scores, -float("inf"),
            )

            n_e_max = tl.maximum(tl.max(scores, axis=2), m_prev)
            re_scale = tl.exp(m_prev - n_e_max)
            p = tl.exp(scores - n_e_max[:, :, None])

            # V dequant — 4-bit + scale + zero
            val_bases = slot_bases + KPS
            val_addrs = val_bases[:, None] + vb_idx[None, :]
            val_raw = tl.load(
                KV_cache_ptr + val_addrs,
                mask=kv_mask[:, None] & d_mask[None, :],
                other=0,
            ).to(tl.int32)
            v_idx = ((val_raw >> vb_shift[None, :]) & 0xF).to(tl.float32)

            sc_bases = val_bases + VAL_DATA_BYTES
            sc_lo = tl.load(KV_cache_ptr + sc_bases, mask=kv_mask, other=0).to(tl.uint16)
            sc_hi = tl.load(KV_cache_ptr + sc_bases + 1, mask=kv_mask, other=0).to(tl.uint16)
            v_scales = (
                (sc_lo | (sc_hi << 8)).to(tl.float16, bitcast=True).to(tl.float32)
            )
            zr_lo = tl.load(KV_cache_ptr + sc_bases + 2, mask=kv_mask, other=0).to(tl.uint16)
            zr_hi = tl.load(KV_cache_ptr + sc_bases + 3, mask=kv_mask, other=0).to(tl.uint16)
            v_zeros = (zr_lo | (zr_hi << 8)).to(tl.float16, bitcast=True).to(tl.float32)
            values = v_idx * v_scales[:, None] + v_zeros[:, None]
            # Sanitize V values too — fp16 scales/zeros can be inf/nan if cache slot uninit.
            values = tl.where((values == values) & (values < 1e30) & (values > -1e30),
                              values, 0.0)

            p_2d = tl.reshape(p, [K_PLUS_1 * BLOCK_H, BLOCK_KV])
            new_acc_2d = tl.dot(
                p_2d.to(tl.float16),
                values.to(tl.float16),
                out_dtype=tl.float32,
            )
            new_acc = tl.reshape(new_acc_2d, [K_PLUS_1, BLOCK_H, BLOCK_D])

            acc = acc * re_scale[:, :, None] + new_acc
            l_prev = l_prev * re_scale + tl.sum(p, axis=2)
            m_prev = n_e_max

        # Phase 2: current chunk K/V (uncompressed FP16, with causal mask)
        chunk_pad_offs = tl.arange(0, BLOCK_KV)
        chunk_pad_mask = chunk_pad_offs < K_PLUS_1

        kk_base = bid * stride_kkb + tl.cast(kv_head, tl.int64) * stride_kkh
        vk_base = bid * stride_vkb + tl.cast(kv_head, tl.int64) * stride_vkh

        chunk_addrs_k_pad = (
            kk_base
            + chunk_pad_offs[:, None] * stride_kkt
            + d_offs[None, :] * stride_kkd
        )
        k_chunk_pad = tl.load(
            K_chunk_ptr + chunk_addrs_k_pad,
            mask=chunk_pad_mask[:, None] & d_mask[None, :],
            other=0.0,
        ).to(tl.float32)

        chunk_addrs_v_pad = (
            vk_base
            + chunk_pad_offs[:, None] * stride_vkt
            + d_offs[None, :] * stride_vkd
        )
        v_chunk_pad = tl.load(
            V_chunk_ptr + chunk_addrs_v_pad,
            mask=chunk_pad_mask[:, None] & d_mask[None, :],
            other=0.0,
        ).to(tl.float32)

        chunk_scores_2d = tl.dot(
            q_2d.to(tl.float16),
            tl.trans(k_chunk_pad.to(tl.float16)),
            out_dtype=tl.float32,
        ) * SCALE
        chunk_scores = tl.reshape(chunk_scores_2d, [K_PLUS_1, BLOCK_H, BLOCK_KV])

        causal_mask = qt_range[:, None, None] >= chunk_pad_offs[None, None, :]
        valid_mask = (
            mask_h[None, :, None]
            & chunk_pad_mask[None, None, :]
            & causal_mask
        )
        chunk_scores = tl.where(valid_mask, chunk_scores, -float("inf"))

        n_e_max = tl.maximum(tl.max(chunk_scores, axis=2), m_prev)
        re_scale_chunk = tl.exp(m_prev - n_e_max)
        p_chunk = tl.exp(chunk_scores - n_e_max[:, :, None])

        p_chunk_2d = tl.reshape(p_chunk, [K_PLUS_1 * BLOCK_H, BLOCK_KV])
        new_acc_chunk_2d = tl.dot(
            p_chunk_2d.to(tl.float16),
            v_chunk_pad.to(tl.float16),
            out_dtype=tl.float32,
        )
        new_acc_chunk = tl.reshape(new_acc_chunk_2d, [K_PLUS_1, BLOCK_H, BLOCK_D])

        acc = acc * re_scale_chunk[:, :, None] + new_acc_chunk
        l_prev = l_prev * re_scale_chunk + tl.sum(p_chunk, axis=2)
        m_prev = n_e_max

        safe_l = tl.where(l_prev > 0.0, l_prev, 1.0)
        out = acc / safe_l[:, :, None]

        o_base = bid * stride_ob
        o_addrs = (
            o_base
            + qt_range[:, None, None] * stride_ot
            + cur_head[None, :, None] * stride_oh
            + d_offs[None, None, :] * stride_od
        )
        tl.store(
            O_ptr + o_addrs, out,
            mask=mask_h[None, :, None] & d_mask[None, None, :],
        )

    return _p67_v4_compressed_cache


def _get_kernel():
    """Lazily build + cache the kernel."""
    global _CACHED_KERNEL
    if _CACHED_KERNEL is None:
        _CACHED_KERNEL = _build_kernel()
    return _CACHED_KERNEL


# ─── Auto-config per SM ──────────────────────────────────────────────────


def _autoconfig(sm_major: int, sm_minor: int, head_dim: int) -> dict:
    """Pick BLOCK_KV/BLOCK_H/num_warps per SM. Conservative defaults.

    Ampere SM 8.6 (A5000/A6000): 100 KB shared mem cap, 4 warps/CTA optimal
    Ampere SM 8.0 (A100): 167 KB shared mem cap, can go larger
    Ada SM 8.9 (4090): 100 KB shared, 4 warps
    Hopper SM 9.0 (H100): 228 KB shared mem cap, can go very large

    All configs use BLOCK_H=16 (matches Hq groups), num_stages=2 (pipeline).
    """
    if sm_major >= 9:
        return dict(BLOCK_KV=32, BLOCK_H=16, num_warps=8, num_stages=3)
    if sm_major == 8 and sm_minor >= 9:
        return dict(BLOCK_KV=32, BLOCK_H=16, num_warps=4, num_stages=2)
    if sm_major == 8 and sm_minor == 0:
        return dict(BLOCK_KV=32, BLOCK_H=16, num_warps=8, num_stages=3)
    if sm_major == 8:
        return dict(BLOCK_KV=16, BLOCK_H=16, num_warps=4, num_stages=2)
    return dict(BLOCK_KV=16, BLOCK_H=16, num_warps=4, num_stages=2)


def _detect_fp8_mode() -> int:
    """Return 1 for e4b15 (Ampere/Ada), 0 for e4nv (Hopper+).

    Mirrors upstream `triton_turboquant_decode._use_fp8_e4b15` decision.
    """
    try:
        import torch
        cap = torch.cuda.get_device_capability()
        return 1 if cap < (8, 9) else 0
    except Exception:
        return 1  # safe default for Ampere/Ada


# ─── Public API ──────────────────────────────────────────────────────────


def is_active() -> bool:
    """Return True if env flag is set AND kernel is buildable on this host."""
    if not _env_enabled():
        return False
    if _get_kernel() is None:
        return False
    return True


def call_p67_attention(
    q,                  # [B, K_PLUS_1, Hq, D] fp16 — query
    kv_cache,           # uint8 [num_blocks, block_size, Hk, slot_size]
    block_table,        # [B, max_blocks] int32
    seq_lens,           # [B] int32 — prior cached length
    k_chunk,            # [B, K_PLUS_1, Hk, D] fp16 — current chunk K
    v_chunk,            # [B, K_PLUS_1, Hk, D] fp16 — current chunk V
    scale: float,
    block_size: int,    # KV cache page block size
    kps: int,           # key payload size bytes per slot (= HEAD_DIM for FP8)
    val_data_bytes: int, # value index bytes (= HEAD_DIM/2 for 4-bit)
    output=None,        # optional preallocated [B, K_PLUS_1, Hq, D]
):
    """Production launcher for P67 multi-query attention.

    Returns: tensor [B, K_PLUS_1, Hq, D] fp16 (matches input q dtype).

    Raises ImportError if Triton/CUDA unavailable. Caller must check is_active()
    first and route to fallback (eager continuation branch) if not available.
    """
    import torch
    import triton

    kernel = _get_kernel()
    if kernel is None:
        raise ImportError("P67 Triton kernel not available")

    B, K_PLUS_1, Hq, D = q.shape
    Hk = k_chunk.shape[2]
    assert k_chunk.shape == (B, K_PLUS_1, Hk, D), (
        f"k_chunk shape mismatch: got {k_chunk.shape}, expected ({B},{K_PLUS_1},{Hk},{D})"
    )
    assert v_chunk.shape == (B, K_PLUS_1, Hk, D)
    assert Hq % Hk == 0
    kv_group_size = Hq // Hk

    # Auto-config per SM
    cap = torch.cuda.get_device_capability()
    cfg = _autoconfig(cap[0], cap[1], D)
    block_kv = cfg["BLOCK_KV"]
    block_h = max(16, cfg["BLOCK_H"])

    BLOCK_D = triton.next_power_of_2(D)

    if output is None:
        output = torch.empty_like(q, dtype=torch.float32)

    heads_per_kv = triton.cdiv(kv_group_size, block_h)
    num_head_groups = Hk * heads_per_kv

    fp8_e4b15 = _detect_fp8_mode()
    skip_phase_1 = 1 if os.environ.get("GENESIS_P67_SKIP_PHASE_1") in ("1", "true") else 0

    grid = (B, num_head_groups, 1)
    kernel[grid](
        q, kv_cache, block_table, seq_lens,
        k_chunk, v_chunk, output,
        q.stride(0), q.stride(1), q.stride(2), q.stride(3),
        kv_cache.stride(0), kv_cache.stride(1), kv_cache.stride(2),
        block_table.stride(0),
        k_chunk.stride(0), k_chunk.stride(1), k_chunk.stride(2), k_chunk.stride(3),
        v_chunk.stride(0), v_chunk.stride(1), v_chunk.stride(2), v_chunk.stride(3),
        output.stride(0), output.stride(1), output.stride(2), output.stride(3),
        SCALE=scale,
        K_PLUS_1=K_PLUS_1,
        BLOCK_D=BLOCK_D,
        HEAD_DIM=D,
        BLOCK_SIZE=block_size,
        BLOCK_KV=block_kv,
        BLOCK_H=block_h,
        KV_GROUP_SIZE=kv_group_size,
        Hq_TOTAL=Hq,
        KPS=kps,
        VAL_DATA_BYTES=val_data_bytes,
        FP8_E4B15=fp8_e4b15,
        SKIP_PHASE_1=skip_phase_1,
        num_warps=cfg["num_warps"],
        num_stages=cfg["num_stages"],
    )
    return output.to(q.dtype)


def diagnostic_info() -> dict[str, Any]:
    """For Genesis dispatcher matrix dump — describe P67 state."""
    info = {"env_enabled": _env_enabled()}
    try:
        import torch
        if torch.cuda.is_available():
            cap = torch.cuda.get_device_capability()
            info["sm"] = f"{cap[0]}.{cap[1]}"
            info["fp8_mode"] = "e4b15" if cap < (8, 9) else "e4nv"
            info["autoconfig"] = _autoconfig(cap[0], cap[1], 128)
        else:
            info["cuda"] = False
    except Exception as e:
        info["error"] = str(e)
    info["kernel_built"] = _get_kernel() is not None
    return info
